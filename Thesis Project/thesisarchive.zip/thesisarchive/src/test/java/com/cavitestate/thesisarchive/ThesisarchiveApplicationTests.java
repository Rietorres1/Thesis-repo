package com.cavitestate.thesisarchive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThesisarchiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
