package com.cavitestate.thesisarchive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThesisarchiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThesisarchiveApplication.class, args);
	}

}
